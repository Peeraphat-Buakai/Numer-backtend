const math = require('mathjs')
const result = async (val) => {

  console.log(val);

}

module.exports = { result }